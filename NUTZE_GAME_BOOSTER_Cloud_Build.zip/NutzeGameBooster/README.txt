NUTZE GAME BOOSTER V2 — ROG-inspired build for Android 16 / Redmi 13X

Included features:
- User-provided NUTZE logo as app icon and splash-screen logo.
- Animated splash screen (fade + scale).
- Device RAM and storage information.
- List of installed user apps with launch buttons.
- Graphics preset: Very Low (burik), Low, Medium, High.
- Sensitivity sliders: General, Red Dot, 2x, 4x, Sniper, Free Look (0–200).
- FPS target presets: 30, 60, 90, 120 FPS.
- Crosshair preview: Dot, Plus, Cross, Circle; Red, Green, White, Cyan.
- Preferences are saved locally on the device.

Important limitations:
The graphics, sensitivity, FPS and crosshair settings are saved as presets/reference inside NUTZE. Normal Android apps cannot force changes to another game's internal graphics/sensitivity/FPS settings or inject a crosshair into another game. Choose matching settings inside the game itself. FPS options are target labels only and do not unlock unsupported frame rates.

Build on GitHub Actions:
Use the repository workflow already created in the previous instructions. Replace the old ZIP in the repository with this updated ZIP, keeping the repository file name exactly NUTZE_GAME_BOOSTER_Cloud_Build.zip. Then run Actions > Build NUTZE APK > Run workflow. Download the artifact NUTZE-GAME-BOOSTER-APK after Success.
