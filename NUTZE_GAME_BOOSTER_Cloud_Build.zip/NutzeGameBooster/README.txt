NUTZE GAME BOOSTER — Android Studio project

Cara membuat APK:
1. Ekstrak ZIP ini.
2. Buka Android Studio.
3. Pilih Open, lalu pilih folder NutzeGameBooster.
4. Tunggu Gradle Sync selesai.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK biasanya tersedia di app/build/outputs/apk/debug/app-debug.apk.

Fitur:
- Tampilan gelap merah bergaya ROG.
- Informasi RAM dan penyimpanan perangkat.
- Daftar aplikasi pengguna yang dapat dibuka.
- Pintasan ke pengaturan Android.

Batasan:
Aplikasi biasa tidak dapat menjamin kenaikan FPS atau mengubah clock CPU/GPU, dan Android membatasi akses untuk menghentikan proses aplikasi lain. Kode ini tidak melakukan root, tidak mengubah sistem, dan tidak menghapus data pengguna.
Target compile SDK 35; gunakan Android Studio dengan Android SDK 35 terpasang.
