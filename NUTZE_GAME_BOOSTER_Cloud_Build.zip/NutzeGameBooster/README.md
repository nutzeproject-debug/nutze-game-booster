# NUTZE GAME BOOSTER V3
Android project for Redmi 13X / Android 16. Includes NUTZE logo, animated splash-like home entrance, Free Fire launcher, saved sensitivity presets, custom graphics/FPS profile selectors, and optional floating companion panel.

## Build
Use JDK 17 and Gradle 8.9:
`gradle assembleDebug`
APK: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions
The existing workflow expects `NUTZE_GAME_BOOSTER_Cloud_Build.zip` at repository root, unzips it, then runs Gradle with `-p NutzeGameBooster`. This archive contains the `NutzeGameBooster/` project folder.

## Important limitations
The app does not inject into Free Fire, modify game files, force graphics/FPS, or apply sensitivity automatically. Values are saved as reference presets for manual application. Floating panel requires the Android "Display over other apps" permission. Free Fire package launch checks Global and MAX package IDs.
