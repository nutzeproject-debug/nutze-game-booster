# NUTZE GAME BOOSTER V6

Project Android untuk dibuild menjadi APK melalui GitHub Actions.

## Build
- Android Gradle Plugin 8.7.3, Compile SDK 35, Java 17.
- Jalankan `gradle assembleDebug` dari folder project.
- APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Fitur V6
- Dashboard hitam-merah; navigasi Home, Games, Space, Account.
- Pilihan Free Fire reguler dan Free Fire MAX.
- Floating panel biru transparan, logo bubble dapat digeser, panel dapat dibuka/minimalkan/ditutup.
- Menu info perangkat, crosshair overlay sederhana, dan pengaturan panel.
- Pilihan Shizuku atau Wireless Debugging untuk rencana integrasi lanjutan.
- Akun lokal demo dan informasi rencana Premium.

## Batasan
- ID akun saat ini hanya ID demo lokal perangkat. ID berurutan global dan aturan 100 akun Premium pertama membutuhkan backend server, database, dan autentikasi.
- Pembayaran QRIS belum aktif di V6; diperlukan penyedia pembayaran dan verifikasi server.
- V6 tidak mengubah sensitivitas internal Free Fire, file game, FPS game, atau grafik game. Overlay tunduk pada izin Android.
- Pada perangkat non-root, Shizuku umumnya perlu aktivasi awal melalui Wireless Debugging.
