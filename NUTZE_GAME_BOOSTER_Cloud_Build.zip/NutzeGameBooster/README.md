# NUTZE GAME BOOSTER V7 - Supabase-connected source

## Included
- V6 game library and floating panel retained.
- Account screen with Supabase email registration/login.
- Reads the authenticated user's `nutze_id` and `is_premium` from `public.profiles`.
- App version 7.0 and Internet permission.

## Supabase configuration
`app/src/main/java/com/nutze/gamebooster/SupabaseConfig.java` contains the project URL and publishable key supplied for this project. Publishable keys are intended for client apps; never put a `sb_secret_` key or service-role key in the APK.

## Database requirements
The `public.profiles` table must have `id` referencing `auth.users(id)`, `nutze_id`, `is_premium`, and `created_at`. The auth user trigger must create the profile and assign the sequential ID. RLS must allow an authenticated user to SELECT only their own row (`auth.uid() = id`). Do not allow clients to INSERT/UPDATE `is_premium` or `nutze_id`; only trusted server-side code/admin may change premium status.

## Build
Open this folder in Android Studio or use the project's existing GitHub Actions workflow. This ZIP is source code, not a compiled APK. Build and test are still required. Registration may require email confirmation depending on Supabase Auth settings.

## Limitations
The V7 account integration does not include QRIS/payment processing. Premium status is displayed from the database and must be granted by a trusted server-side process. The app's floating panel is a UI overlay; it does not modify Free Fire game data or guarantee FPS/sensitivity changes.
