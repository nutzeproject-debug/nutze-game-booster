package com.nutze.gamebooster;

final class SupabaseConfig {
    static final String URL = "https://okjskzbcozmudxtvqdff.supabase.co";
    static final String PUBLISHABLE_KEY = "sb_publishable_0_t4kjPZO-ZE1f6BNPqaFg_JEiy8HPR";
    private SupabaseConfig() {}
}
