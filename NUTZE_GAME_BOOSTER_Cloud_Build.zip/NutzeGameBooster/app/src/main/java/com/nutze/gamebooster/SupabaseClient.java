package com.nutze.gamebooster;

import org.json.JSONObject;
import java.io.*;
import java.net.*;

final class SupabaseClient {
    interface Callback { void done(JSONObject result, String error); }
    static void auth(String mode, String email, String password, Callback cb) {
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                String path = mode.equals("signup") ? "/auth/v1/signup" : "/auth/v1/token?grant_type=password";
                URL u = new URL(SupabaseConfig.URL + path);
                c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(15000);
                c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY);
                JSONObject body = new JSONObject(); body.put("email", email); body.put("password", password);
                try (OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes("UTF-8")); }
                int code = c.getResponseCode(); InputStream is = code < 400 ? c.getInputStream() : c.getErrorStream();
                String response = read(is); JSONObject json = new JSONObject(response);
                if (code >= 400) cb.done(null, json.optString("msg", json.optString("message", "Permintaan gagal ("+code+")")));
                else cb.done(json, null);
            } catch (Exception e) { cb.done(null, "Koneksi gagal: " + e.getMessage()); }
            finally { if (c != null) c.disconnect(); }
        }).start();
    }
    static void profile(String accessToken, Callback cb) {
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                URL u = new URL(SupabaseConfig.URL + "/rest/v1/profiles?select=nutze_id,is_premium&limit=1");
                c = (HttpURLConnection) u.openConnection(); c.setRequestMethod("GET");
                c.setConnectTimeout(15000); c.setReadTimeout(15000);
                c.setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY);
                c.setRequestProperty("Authorization", "Bearer " + accessToken);
                int code = c.getResponseCode(); InputStream is = code < 400 ? c.getInputStream() : c.getErrorStream();
                String response = read(is);
                if (code >= 400) cb.done(null, "Gagal membaca profil ("+code+"): " + response);
                else { org.json.JSONArray a = new org.json.JSONArray(response); cb.done(a.length() > 0 ? a.getJSONObject(0) : new JSONObject(), null); }
            } catch (Exception e) { cb.done(null, "Profil belum tersedia: " + e.getMessage()); }
            finally { if (c != null) c.disconnect(); }
        }).start();
    }
    private static String read(InputStream is) throws Exception {
        if (is == null) return ""; ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] b = new byte[2048]; int n;
        while ((n = is.read(b)) != -1) out.write(b, 0, n); return out.toString("UTF-8");
    }
}
