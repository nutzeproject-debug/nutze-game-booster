package com.nutze.gamebooster;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.*;
import java.util.List;

public class MainActivity extends Activity {
    private final int BG=0xFF080809, RED=0xFFFF3038, WHITE=Color.WHITE, MUTED=0xFFAAAAAA;
    private LinearLayout root, gamesBox;
    private TextView crosshairPreview;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences("nutze_settings", MODE_PRIVATE);
        showSplash();
    }

    private GradientDrawable bg(int color,int radius,int stroke) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius);
        if(stroke!=0)d.setStroke(2,stroke); return d;
    }
    private TextView txt(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    private void showSplash() {
        LinearLayout splash=new LinearLayout(this); splash.setGravity(Gravity.CENTER);
        splash.setOrientation(LinearLayout.VERTICAL); splash.setBackgroundColor(Color.BLACK);
        ImageView logo=new ImageView(this); logo.setImageResource(com.nutze.gamebooster.R.drawable.nutze_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        splash.addView(logo,new LinearLayout.LayoutParams(280,280));
        TextView brand=txt("NUTZE GAME BOOSTER",18,WHITE,true);
        brand.setGravity(Gravity.CENTER); brand.setPadding(0,20,0,0); splash.addView(brand);
        TextView loading=txt("ROG EDITION  •  INITIALIZING",10,RED,true);
        loading.setGravity(Gravity.CENTER); loading.setPadding(0,8,0,0); splash.addView(loading);
        setContentView(splash);
        AlphaAnimation fade=new AlphaAnimation(0f,1f); fade.setDuration(1100); logo.startAnimation(fade);
        ScaleAnimation scale=new ScaleAnimation(.82f,1f,.82f,1f,ScaleAnimation.RELATIVE_TO_SELF,.5f,ScaleAnimation.RELATIVE_TO_SELF,.5f);
        scale.setDuration(1100); logo.startAnimation(scale);
        splash.postDelayed(this::showHome,1500);
    }
    private void setupRoot() {
        ScrollView scroll=new ScrollView(this);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20,26,20,28); root.setBackgroundColor(BG); scroll.addView(root); setContentView(scroll);
        TextView eyebrow=txt("NUTZE  //  ROG EDITION",12,RED,true); root.addView(eyebrow);
        TextView title=txt("GAME BOOSTER",27,WHITE,true); title.setPadding(0,5,0,2); root.addView(title);
        root.addView(txt("PERSONAL GAMING CONTROL PANEL",10,MUTED,true));
    }
    private LinearLayout panel(String heading) {
        LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setPadding(15,14,15,14);
        p.setBackground(bg(0xFF171719,16,0xFF552126));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.topMargin=16; p.setLayoutParams(lp);
        p.addView(txt(heading,14,RED,true)); return p;
    }
    private Button btn(String s) {
        Button b=new Button(this); b.setText(s); b.setTextColor(WHITE); b.setTextSize(12);
        b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setBackground(bg(0xFF9E101A,12,RED)); return b;
    }
    private void showHome() {
        setupRoot();
        LinearLayout device=panel("DEVICE STATUS");
        ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();
        ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);
        device.addView(txt("RAM tersedia: "+(mi.availMem/1048576)+" MB / "+(mi.totalMem/1048576)+" MB",15,WHITE,true));
        StatFs fs=new StatFs(Environment.getDataDirectory().getPath());
        device.addView(txt("Penyimpanan kosong: "+(fs.getAvailableBytes()/1073741824L)+" GB",13,MUTED,false));
        root.addView(device);

        LinearLayout settings=panel("GAMING TUNING");
        addChoice(settings,"Preset grafik",new String[]{"Very Low (burik)","Low","Medium","High"}, "graphics","Very Low (burik)");
        addSeek(settings,"General sensitivity", "sens_general",0,200,100);
        addSeek(settings,"Red Dot sensitivity", "sens_red_dot",0,200,95);
        addSeek(settings,"2x Scope sensitivity", "sens_2x",0,200,90);
        addSeek(settings,"4x Scope sensitivity", "sens_4x",0,200,85);
        addSeek(settings,"Sniper sensitivity", "sens_sniper",0,200,60);
        addSeek(settings,"Free Look sensitivity", "sens_free_look",0,200,100);
        addChoice(settings,"Target FPS",new String[]{"30 FPS","60 FPS","90 FPS","120 FPS"}, "fps","60 FPS");
        addChoice(settings,"Crosshair style",new String[]{"Dot","Plus","Cross","Circle"}, "crosshair","Plus");
        addChoice(settings,"Crosshair color",new String[]{"Red","Green","White","Cyan"}, "cross_color","Red");
        crosshairPreview=txt(crosshairGlyph(prefs.getString("crosshair","Plus")),30,crosshairColor(prefs.getString("cross_color","Red")),true);
        crosshairPreview.setGravity(Gravity.CENTER); crosshairPreview.setPadding(0,10,0,10); settings.addView(crosshairPreview);
        settings.addView(txt("Pengaturan ini disimpan sebagai preset/referensi. Perubahan grafik, sensitivitas, FPS, dan crosshair tidak otomatis diterapkan ke dalam game.",10,MUTED,false));
        root.addView(settings);

        LinearLayout gamePanel=panel("INSTALLED GAMES");
        TextView note=txt("Pilih game untuk membukanya.",12,MUTED,false); gamePanel.addView(note);
        gamesBox=new LinearLayout(this); gamesBox.setOrientation(LinearLayout.VERTICAL); gamePanel.addView(gamesBox);
        root.addView(gamePanel); loadGames();

        Button openSettings=btn("OPEN ANDROID GAME SETTINGS");
        openSettings.setOnClickListener(v->{ startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); });
        LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,-2); op.topMargin=16; root.addView(openSettings,op);
        TextView footer=txt("NUTZE • Built for Android | No root required",10,0xFF777777,false);
        footer.setGravity(Gravity.CENTER); footer.setPadding(0,20,0,0); root.addView(footer);
    }
    private void addChoice(LinearLayout box,String label,String[] values,String key,String def) {
        TextView l=txt(label,12,WHITE,true); l.setPadding(0,12,0,4); box.addView(l);
        Spinner sp=new Spinner(this); ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,values);
        sp.setAdapter(a); String saved=prefs.getString(key,def);
        for(int i=0;i<values.length;i++)if(values[i].equals(saved))sp.setSelection(i);
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){prefs.edit().putString(key,values[pos]).apply(); if(crosshairPreview!=null && ("crosshair".equals(key)||"cross_color".equals(key))){crosshairPreview.setText(crosshairGlyph(prefs.getString("crosshair","Plus")));crosshairPreview.setTextColor(crosshairColor(prefs.getString("cross_color","Red")));}}
        }); box.addView(sp);
    }
    private void addSeek(LinearLayout box,String label,String key,int min,int max,int def) {
        TextView l=txt(label+"  •  "+prefs.getInt(key,def),12,WHITE,true); l.setPadding(0,12,0,0); box.addView(l);
        SeekBar sb=new SeekBar(this); sb.setMax(max-min); sb.setProgress(prefs.getInt(key,def)-min);
        sb.setProgressTintList(android.content.res.ColorStateList.valueOf(RED));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean user){l.setText(label+"  •  "+(p+min)); if(user)prefs.edit().putInt(key,p+min).apply();}
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){}
        }); box.addView(sb);
    }
    private String crosshairGlyph(String style) {
        if ("Dot".equals(style)) return "•";
        if ("Cross".equals(style)) return "×";
        if ("Circle".equals(style)) return "⊙";
        return "+";
    }
    private int crosshairColor(String color) {
        if ("Green".equals(color)) return 0xFF39FF72;
        if ("White".equals(color)) return Color.WHITE;
        if ("Cyan".equals(color)) return 0xFF39E7FF;
        return RED;
    }
    private void loadGames() {
        PackageManager pm=getPackageManager(); List<ApplicationInfo> apps=pm.getInstalledApplications(PackageManager.GET_META_DATA);
        int count=0;
        for(ApplicationInfo app:apps) {
            if(pm.getLaunchIntentForPackage(app.packageName)==null || (app.flags&ApplicationInfo.FLAG_SYSTEM)!=0)continue;
            String name=pm.getApplicationLabel(app).toString();
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(4,8,4,8);
            TextView n=txt(name,13,WHITE,true); row.addView(n,new LinearLayout.LayoutParams(0,-2,1));
            Button open=btn("BUKA"); open.setOnClickListener(v->{Intent i=pm.getLaunchIntentForPackage(app.packageName);if(i!=null)startActivity(i);});
            row.addView(open); gamesBox.addView(row); count++;
        }
        if(count==0)gamesBox.addView(txt("Tidak ada game pengguna yang terdeteksi.",12,MUTED,false));
    }
}
