package com.nutze.gamebooster;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(9,9,11);
    private final int RED = Color.rgb(255,48,48);
    private LinearLayout root, gameList;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        buildUi();
    }

    private GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if (stroke > 0) d.setStroke(2, stroke);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 28, 22, 28);
        root.setBackgroundColor(BG);
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = text("NUTZE  //  GAMING", 14, RED, true);
        root.addView(brand);
        TextView title = text("GAME BOOSTER", 29, Color.WHITE, true);
        title.setPadding(0, 8, 0, 4); root.addView(title);
        TextView sub = text("ROG-INSPIRED PERFORMANCE HUB", 11, 0xFFAAAAAA, true);
        root.addView(sub);

        LinearLayout status = panel();
        status.setOrientation(LinearLayout.VERTICAL);
        TextView statusTitle = text("DEVICE STATUS", 13, RED, true);
        status.addView(statusTitle);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);
        long total = mi.totalMem / (1024*1024);
        long available = mi.availMem / (1024*1024);
        status.addView(text("RAM tersedia: " + available + " MB / " + total + " MB", 16, Color.WHITE, true));
        StatFs fs = new StatFs(Environment.getDataDirectory().getPath());
        long free = fs.getAvailableBytes() / (1024*1024*1024);
        long all = fs.getTotalBytes() / (1024*1024*1024);
        status.addView(text("Penyimpanan kosong: " + free + " GB / " + all + " GB", 14, 0xFFCCCCCC, false));
        root.addView(status);

        TextView mode = text("GAMING MODE", 17, Color.WHITE, true);
        mode.setPadding(0, 20, 0, 8); root.addView(mode);
        Button settings = button("BUKA PENGATURAN GAME");
        settings.setOnClickListener(v -> {
            Intent i = new Intent(android.provider.Settings.ACTION_SETTINGS);
            startActivity(i);
        });
        root.addView(settings);

        TextView games = text("GAME YANG TERPASANG", 17, Color.WHITE, true);
        games.setPadding(0, 22, 0, 8); root.addView(games);
        TextView hint = text("Pilih game untuk membukanya.", 12, 0xFFAAAAAA, false);
        root.addView(hint);
        gameList = new LinearLayout(this);
        gameList.setOrientation(LinearLayout.VERTICAL);
        root.addView(gameList);
        loadGames();

        TextView note = text("Catatan: Android membatasi aplikasi pihak ketiga untuk mengubah FPS, membersihkan RAM aplikasi lain, atau mengatur CPU/GPU secara langsung. Aplikasi ini menampilkan info perangkat dan pintasan yang aman.", 11, 0xFF999999, false);
        note.setPadding(0, 24, 0, 10); root.addView(note);
    }

    private LinearLayout panel() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(16,16,16,16);
        p.setBackground(shape(0xFF171719, 18, RED));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = 22; p.setLayoutParams(lp);
        return p;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE);
        b.setTextSize(13); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(shape(0xFFB5121B, 14, RED));
        return b;
    }

    private void loadGames() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        int count = 0;
        for (ApplicationInfo app : apps) {
            if (pm.getLaunchIntentForPackage(app.packageName) == null) continue;
            if ((app.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            String name = pm.getApplicationLabel(app).toString();
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(12, 10, 12, 10);
            row.setBackground(shape(0xFF171719, 12, 0));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.topMargin = 7; row.setLayoutParams(rp);
            TextView label = text(name, 15, Color.WHITE, true);
            row.addView(label, new LinearLayout.LayoutParams(0, -2, 1));
            Button open = button("BUKA");
            open.setOnClickListener(v -> {
                Intent launch = pm.getLaunchIntentForPackage(app.packageName);
                if (launch != null) startActivity(launch);
            });
            row.addView(open);
            gameList.addView(row);
            count++;
        }
        if (count == 0) {
            TextView empty = text("Belum ada aplikasi pengguna yang bisa ditampilkan.", 13, 0xFFBBBBBB, false);
            empty.setPadding(0, 12, 0, 0); gameList.addView(empty);
        }
    }
}
