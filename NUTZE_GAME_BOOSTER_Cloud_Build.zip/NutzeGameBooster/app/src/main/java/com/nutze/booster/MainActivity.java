package com.nutze.booster;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.view.animation.*;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root;
    int red=Color.rgb(255,48,48);
    android.content.SharedPreferences prefs;
    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density); }
    public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences("nutze",0); showHome(); }
    TextView text(String s,int size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t; }
    GradientDrawable bg(int color,int radius){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    void init(String title){
        ScrollView sc=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(20),dp(18),dp(20),dp(24)); root.setBackgroundColor(Color.rgb(9,9,9)); sc.addView(root); setContentView(sc);
        TextView h=text(title,23,Color.WHITE); h.setTypeface(null,Typeface.BOLD); root.addView(h);
    }
    void gap(int h){ Space s=new Space(this); root.addView(s,new LinearLayout.LayoutParams(1,dp(h))); }
    void card(String title,String subtitle){
        LinearLayout c=new LinearLayout(this); c.setOrientation(1); c.setPadding(dp(16),dp(13),dp(16),dp(13)); c.setBackground(bg(Color.rgb(28,28,30),16));
        TextView a=text(title,16,Color.WHITE); a.setTypeface(null,Typeface.BOLD); c.addView(a);
        TextView b=text(subtitle,12,0xffbbbbbb); c.addView(b); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(10); root.addView(c,p);
    }
    Button btn(String label, Runnable r){
        Button b=new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackground(bg(0xffc62828,14)); b.setOnClickListener(v->r.run()); return b;
    }
    void showHome(){
        init("NUTZE GAME BOOSTER");
        ImageView logo=new ImageView(this); logo.setImageResource(com.nutze.booster.R.drawable.nutze_logo); logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(150),dp(150)); lp.gravity=Gravity.CENTER; logo.setLayoutParams(lp); root.addView(logo);
        logo.setAlpha(0f); logo.animate().alpha(1f).setDuration(900).start();
        TextView sub=text("ROG EDITION  •  FREE FIRE",12,0xffff5555); sub.setGravity(Gravity.CENTER); root.addView(sub); gap(20);
        card("DEVICE","Redmi 13X • Android 16\nPreset disimpan di NUTZE, bukan diubah langsung di Free Fire.");
        root.addView(btn("▶  START FREE FIRE",()->launchGame()),new LinearLayout.LayoutParams(-1,dp(52))); gap(10);
        root.addView(btn("⚙  PENGATURAN CUSTOM",()->showSettings()),new LinearLayout.LayoutParams(-1,dp(52))); gap(10);
        root.addView(btn("◉  AKTIFKAN FLOATING PANEL",()->enablePanel()),new LinearLayout.LayoutParams(-1,dp(52))); gap(10);
        card("CATATAN","Panel mengambang menampilkan preset NUTZE. Grafik, sensitivitas, crosshair, dan FPS tidak dapat dipaksakan ke dalam Free Fire oleh aplikasi ini.");
    }
    void launchGame(){
        String[] pkgs={"com.dts.freefireth","com.dts.freefiremax"};
        for(String p:pkgs){ Intent i=getPackageManager().getLaunchIntentForPackage(p); if(i!=null){ startActivity(i); return; } }
        new AlertDialog.Builder(this).setMessage("Free Fire tidak ditemukan. Pastikan Free Fire resmi sudah terpasang.").setPositiveButton("OK",null).show();
    }
    void enablePanel(){
        if(!Settings.canDrawOverlays(this)){
            Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())); startActivity(i); return;
        }
        startService(new Intent(this,FloatingPanelService.class));
        Toast.makeText(this,"Floating panel aktif. Buka Free Fire.",Toast.LENGTH_LONG).show();
    }
    void seek(String label,int max,int def){
        TextView tv=text(label+" : "+prefs.getInt(label,def),14,Color.WHITE); root.addView(tv);
        SeekBar sb=new SeekBar(this); sb.setMax(max); sb.setProgress(prefs.getInt(label,def)); sb.setProgressTintList(android.content.res.ColorStateList.valueOf(red)); sb.setThumbTintList(android.content.res.ColorStateList.valueOf(red));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar s,int v,boolean u){tv.setText(label+" : "+v); if(u)prefs.edit().putInt(label,v).apply();} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){} });
        root.addView(sb); gap(8);
    }
    void showSettings(){
        init("CUSTOM GAMING PROFILE"); gap(12);
        card("SENSITIVITY","Simpan nilai rekomendasi untuk dilihat saat bermain. Terapkan manual di pengaturan Free Fire.");
        seek("General",200,100); seek("Red Dot",200,95); seek("2x Scope",200,90); seek("4x Scope",200,85); seek("Sniper",200,60); seek("Free Look",200,100);
        card("GRAPHICS PRESET","Pilihan ini hanya catatan preset. Tidak mengubah file atau kualitas grafis game secara otomatis.");
        String[] modes={"Very Low / Burik","Low","Medium","Custom"}; Spinner sp=new Spinner(this); sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,modes)); sp.setSelection(prefs.getInt("graphics",3)); sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){} public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){prefs.edit().putInt("graphics",pos).apply();}}); root.addView(sp);
        card("FPS TARGET","Pilih target sebagai catatan. FPS aktual ditentukan game dan kemampuan perangkat.");
        Spinner fps=new Spinner(this); fps.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"30 FPS","60 FPS","90 FPS","120 FPS"})); fps.setSelection(prefs.getInt("fps",1)); fps.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){} public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){prefs.edit().putInt("fps",pos).apply();}}); root.addView(fps);
        card("CROSSHAIR","Preview konsep saja; tidak ditampilkan di atas Free Fire."); Spinner cr=new Spinner(this); cr.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Dot","Plus","Cross","Circle"})); root.addView(cr);
        gap(12); root.addView(btn("← KEMBALI",()->showHome()));
    }
}
