package com.nutze.booster;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingPanelService extends Service {
    private WindowManager wm;
    private View current;
    private WindowManager.LayoutParams params;
    private boolean collapsed = false;
    private final int blue = 0xff102d55;
    private final int cyan = 0xff56c8ff;
    private int dp(float v) { return (int)(getResources().getDisplayMetrics().density * v); }

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onCreate() {
        super.onCreate(); wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        params = new WindowManager.LayoutParams(dp(340), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL; params.y = dp(24);
        showPanel();
    }
    private GradientDrawable bg(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke); return d;
    }
    private TextView label(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); return t;
    }
    private LinearLayout column() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void tile(LinearLayout parent, String title, String detail, Runnable action) {
        LinearLayout box=column(); box.setGravity(Gravity.CENTER); box.setPadding(dp(4),dp(7),dp(4),dp(7));
        box.setBackground(bg(0xdd10264a,0xff56bfff,11));
        TextView a=label(title,11,Color.WHITE); a.setTypeface(null,1); box.addView(a);
        box.addView(label(detail,8,0xffb8e5ff)); box.setOnClickListener(v->action.run());
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(57),1f); lp.setMargins(dp(3),0,dp(3),0); parent.addView(box,lp);
    }
    private void openSelectedApp() {
        String pkg=getSharedPreferences("nutze",0).getString("selected_package","");
        if(pkg.isEmpty()){ Toast.makeText(this,"Pilih aplikasi di NUTZE terlebih dahulu",Toast.LENGTH_SHORT).show(); return; }
        Intent i=getPackageManager().getLaunchIntentForPackage(pkg);
        if(i!=null){ i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); }
        else Toast.makeText(this,"Aplikasi pilihan tidak ditemukan",Toast.LENGTH_SHORT).show();
    }
    private void showPanel() {
        LinearLayout root=column(); root.setPadding(dp(10),dp(9),dp(10),dp(9));
        root.setBackground(bg(0xee09264a,0xff56c8ff,18));
        LinearLayout head=row();
        TextView title=label("NUTZE SPACE  •  FLOATING PANEL",13,Color.WHITE); title.setTypeface(null,1); title.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(title,new LinearLayout.LayoutParams(0,dp(34),1f));
        TextView hide=label("−",22,Color.WHITE); hide.setBackground(bg(0xff164675,cyan,20)); head.addView(hide,new LinearLayout.LayoutParams(dp(34),dp(30)));
        hide.setOnClickListener(v->collapse()); root.addView(head);
        TextView status=label("PANEL AKTIF  |  " + getSharedPreferences("nutze",0).getString("selected_name","BELUM PILIH APLIKASI"),9,0xffbdeaff);
        root.addView(status,new LinearLayout.LayoutParams(-1,dp(25)));
        LinearLayout r1=row(); tile(r1,"APLIKASI","BUKA PILIHAN",this::openSelectedApp); tile(r1,"SETTINGS","ATUR DI SINI",this::showSettings); tile(r1,"MONITOR","INFO PANEL",()->Toast.makeText(this,"Overlay NUTZE sedang aktif",Toast.LENGTH_SHORT).show()); root.addView(r1);
        LinearLayout r2=row(); tile(r2,"SENSITIVITY","NILAI REFERENSI",this::showSettings); tile(r2,"CROSSHAIR","PREVIEW",()->Toast.makeText(this,"Crosshair preview belum diaktifkan",Toast.LENGTH_SHORT).show()); tile(r2,"TUTUP","MATIKAN PANEL",this::stopSelf); root.addView(r2);
        TextView drag=label("•  •  •    GESER DARI SINI    •  •  •",9,0xffa9dcff); root.addView(drag,new LinearLayout.LayoutParams(-1,dp(25)));
        attach(root,dp(340)); drag.setOnTouchListener(dragListener());
    }
    private void showSettings() {
        LinearLayout root=column(); root.setPadding(dp(12),dp(10),dp(12),dp(10)); root.setBackground(bg(0xee09264a,0xff56c8ff,18));
        LinearLayout head=row(); TextView title=label("NUTZE • QUICK SETTINGS",13,Color.WHITE); title.setTypeface(null,1); head.addView(title,new LinearLayout.LayoutParams(0,dp(34),1f));
        TextView back=label("←",20,Color.WHITE); back.setBackground(bg(0xff164675,cyan,18)); head.addView(back,new LinearLayout.LayoutParams(dp(38),dp(32))); back.setOnClickListener(v->showPanel()); root.addView(head);
        root.addView(label("SENSITIVITY (nilai referensi, tidak mengubah game otomatis)",9,0xffbdeaff));
        addSeek(root,"General",100); addSeek(root,"Red Dot",95); addSeek(root,"2x Scope",90); addSeek(root,"4x Scope",85); addSeek(root,"Sniper",60);
        Button done=new Button(this); done.setText("KEMBALI KE PANEL"); done.setTextColor(Color.WHITE); done.setBackground(bg(0xff1764a0,cyan,12)); done.setOnClickListener(v->showPanel()); root.addView(done,new LinearLayout.LayoutParams(-1,dp(44)));
        TextView drag=label("•  •  •    GESER JENDELA DARI SINI    •  •  •",9,0xffa9dcff); root.addView(drag); attach(root,dp(340)); drag.setOnTouchListener(dragListener());
    }
    private void addSeek(LinearLayout root,String key,int def) {
        int value=getSharedPreferences("nutze",0).getInt(key,def);
        TextView t=label(key+" : "+value,11,Color.WHITE); t.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); root.addView(t,new LinearLayout.LayoutParams(-1,dp(20)));
        SeekBar sb=new SeekBar(this); sb.setMax(200); sb.setProgress(value); sb.setProgressTintList(android.content.res.ColorStateList.valueOf(cyan)); sb.setThumbTintList(android.content.res.ColorStateList.valueOf(cyan));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar s,int p,boolean user){t.setText(key+" : "+p); if(user)getSharedPreferences("nutze",0).edit().putInt(key,p).apply();} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){} }); root.addView(sb);
    }
    private void attach(View view,int width) {
        if(current!=null){ try{wm.removeView(current);}catch(Exception ignored){} }
        current=view; params.width=width; params.height=WindowManager.LayoutParams.WRAP_CONTENT;
        try{wm.addView(current,params);}catch(Exception e){stopSelf();}
    }
    private View.OnTouchListener dragListener(){
        return new View.OnTouchListener(){ float sx,sy; int ox,oy;
            public boolean onTouch(View v,MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();ox=params.x;oy=params.y;return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){params.x=ox+(int)(e.getRawX()-sx);params.y=oy+(int)(e.getRawY()-sy);try{wm.updateViewLayout(current,params);}catch(Exception ignored){}return true;}
                return true;
            }
        };
    }
    private void collapse(){
        collapsed=true; LinearLayout bubble=new LinearLayout(this); bubble.setGravity(Gravity.CENTER); bubble.setBackground(bg(0xee09264a,cyan,100));
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.nutze_logo); logo.setScaleType(ImageView.ScaleType.CENTER_CROP); bubble.addView(logo,new LinearLayout.LayoutParams(dp(54),dp(54)));
        bubble.setOnClickListener(v->{collapsed=false;showPanel();}); attach(bubble,dp(62)); params.gravity=Gravity.TOP|Gravity.LEFT; params.x=dp(8); params.y=dp(180); try{wm.updateViewLayout(current,params);}catch(Exception ignored){}
        bubble.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;public boolean onTouch(View v,MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();ox=params.x;oy=params.y;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){params.x=ox+(int)(e.getRawX()-sx);params.y=oy+(int)(e.getRawY()-sy);try{wm.updateViewLayout(current,params);}catch(Exception ignored){}return true;}if(e.getAction()==MotionEvent.ACTION_UP){if(Math.abs(e.getRawX()-sx)<dp(8)&&Math.abs(e.getRawY()-sy)<dp(8)){showPanel();}return true;}return true;}});
    }
    @Override public void onDestroy(){if(current!=null){try{wm.removeView(current);}catch(Exception ignored){}}super.onDestroy();}
}
