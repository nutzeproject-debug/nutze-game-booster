package com.nutze.booster;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingPanelService extends Service {
    private WindowManager wm;
    private View panel;
    private int dp(float v) { return (int)(getResources().getDisplayMetrics().density * v); }

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onCreate() { super.onCreate(); wm = (WindowManager)getSystemService(WINDOW_SERVICE); show(); }

    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size);
        t.setTextColor(color); t.setGravity(Gravity.CENTER); return t;
    }

    private void addTile(LinearLayout row, String label, String sub, Runnable action) {
        LinearLayout tile = new LinearLayout(this); tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER); tile.setPadding(dp(5), dp(7), dp(5), dp(7));
        tile.setBackground(shape(0xdd351014, 0xfff0525b, 12));
        TextView name = text(label, 12, Color.WHITE); name.setTypeface(null, 1);
        TextView detail = text(sub, 9, 0xffffa6aa);
        tile.addView(name); tile.addView(detail);
        tile.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(58), 1f);
        lp.setMargins(dp(3), 0, dp(3), 0); row.addView(tile, lp);
    }

    private void openSelectedApp() {
        String pkg = getSharedPreferences("nutze", 0).getString("selected_package", "");
        if (pkg.isEmpty()) { Toast.makeText(this, "Pilih aplikasi dulu di NUTZE", Toast.LENGTH_SHORT).show(); openNutze(); return; }
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) { Toast.makeText(this, "Aplikasi tidak bisa dibuka", Toast.LENGTH_SHORT).show(); return; }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch);
    }

    private void openNutze() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
    }

    private void show() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(9), dp(12), dp(9));
        root.setBackground(shape(0xee17090c, 0xffff4652, 18));

        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("NUTZE  //  GAME BOOSTER", 14, Color.WHITE);
        title.setGravity(Gravity.CENTER_VERTICAL); title.setTypeface(null, 1);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(30), 1f));
        TextView close = text("✕", 18, 0xffff6971); close.setBackground(shape(0xff40151b, 0xffff4652, 20));
        header.addView(close, new LinearLayout.LayoutParams(dp(34), dp(30)));
        close.setOnClickListener(v -> stopSelf());
        root.addView(header);

        LinearLayout mid = new LinearLayout(this); mid.setGravity(Gravity.CENTER_VERTICAL);
        mid.setPadding(0, dp(6), 0, dp(6));
        LinearLayout stats = new LinearLayout(this); stats.setOrientation(LinearLayout.VERTICAL);
        stats.setGravity(Gravity.CENTER); stats.setBackground(shape(0xcc2b1015, 0xffa8323d, 12));
        TextView fps = text("NUTZE", 21, 0xffff5964); fps.setTypeface(null, 1);
        TextView status = text("PANEL AKTIF", 9, 0xffffc1c4);
        stats.addView(fps); stats.addView(status);
        mid.addView(stats, new LinearLayout.LayoutParams(dp(105), dp(65)));
        TextView app = text("APLIKASI: " + getSharedPreferences("nutze",0).getString("selected_name", "BELUM DIPILIH"), 10, 0xffffdadd);
        app.setPadding(dp(10), 0, dp(4), 0); app.setGravity(Gravity.CENTER_VERTICAL);
        mid.addView(app, new LinearLayout.LayoutParams(0, dp(60), 1f));
        root.addView(mid);

        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        addTile(row, "APLIKASI", "BUKA PILIHAN", this::openSelectedApp);
        addTile(row, "PENGATURAN", "BUKA NUTZE", this::openNutze);
        addTile(row, "SENSITIVITAS", "KONFIGURASI", this::openNutze);
        addTile(row, "MONITOR", "INFO PANEL", () -> Toast.makeText(this, "Panel NUTZE aktif", Toast.LENGTH_SHORT).show());
        root.addView(row);

        TextView drag = text("•  •  •     GESER PANEL DARI SINI     •  •  •", 9, 0xffff8d94);
        drag.setPadding(0, dp(5), 0, 0); root.addView(drag);

        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL; p.y = dp(12);
        drag.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy; int ox, oy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) { sx=e.getRawX(); sy=e.getRawY(); ox=p.x; oy=p.y; return true; }
                if (e.getAction() == MotionEvent.ACTION_MOVE) { p.x=ox+(int)(e.getRawX()-sx); p.y=oy+(int)(e.getRawY()-sy); wm.updateViewLayout(root,p); return true; }
                return true;
            }
        });
        panel = root; wm.addView(panel, p);
    }

    @Override public void onDestroy() { if (panel != null) wm.removeView(panel); super.onDestroy(); }
}
