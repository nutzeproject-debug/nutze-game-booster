package com.nutze.booster;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.*;
import android.widget.*;
import android.content.Context;

public class FloatingPanelService extends Service {
    WindowManager wm; View panel; int dp(float x){return (int)(getResources().getDisplayMetrics().density*x);}
    public IBinder onBind(Intent i){return null;}
    public void onCreate(){super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); show();}
    void show(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(dp(12),dp(10),dp(12),dp(10));
        GradientDrawable gd=new GradientDrawable(); gd.setColor(0xee171719); gd.setCornerRadius(dp(16)); gd.setStroke(dp(1),0xffff4444); box.setBackground(gd);
        TextView title=new TextView(this); title.setText("NUTZE  •  FF"); title.setTextColor(Color.WHITE); title.setTextSize(14); title.setPadding(0,0,0,dp(6)); box.addView(title);
        TextView info=new TextView(this); info.setText("PANEL PENDAMPING\nPreset tersimpan di aplikasi.\nTidak mengubah game."); info.setTextColor(0xffeeeeee); info.setTextSize(11); box.addView(info);
        Button open=new Button(this); open.setText("BUKA NUTZE"); open.setTextSize(10); open.setOnClickListener(v->{Intent i=new Intent(this,MainActivity.class); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);}); box.addView(open);
        Button close=new Button(this); close.setText("TUTUP PANEL"); close.setTextSize(10); close.setOnClickListener(v->stopSelf()); box.addView(close);
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(dp(190),-2,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.RIGHT|Gravity.CENTER_VERTICAL; p.x=dp(8); p.y=0;
        box.setOnTouchListener(new View.OnTouchListener(){float sx,sy; int ox,oy; public boolean onTouch(View v,android.view.MotionEvent e){if(e.getAction()==0){sx=e.getRawX();sy=e.getRawY();ox=p.x;oy=p.y;return true;} if(e.getAction()==2){p.x=ox+(int)(sx-e.getRawX());p.y=oy+(int)(e.getRawY()-sy);wm.updateViewLayout(box,p);return true;} return true;}});
        panel=box; wm.addView(panel,p);
    }
    public void onDestroy(){if(panel!=null)wm.removeView(panel);super.onDestroy();}
}
